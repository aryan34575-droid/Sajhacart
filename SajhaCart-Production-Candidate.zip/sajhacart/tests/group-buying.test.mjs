import test from 'node:test';
import assert from 'node:assert/strict';
import { validateCommitment, priceForQuantity, calculateSavings } from '../lib/group-buying.mjs';

test('rejects fractional and zero quantities', () => {
  assert.equal(validateCommitment({ quantity: 0 }).reason, 'invalid_quantity');
  assert.equal(validateCommitment({ quantity: 1.5 }).reason, 'invalid_quantity');
});
test('rejects closed, expired and over-stock orders', () => {
  assert.equal(validateCommitment({ quantity: 1, status: 'closed' }).reason, 'order_closed');
  assert.equal(validateCommitment({ quantity: 1, deadline: '2020-01-01T00:00:00Z' }).reason, 'deadline_passed');
  assert.equal(validateCommitment({ quantity: 4, availableQuantity: 3 }).reason, 'insufficient_stock');
});
test('valid commitment passes', () => {
  assert.deepEqual(validateCommitment({ quantity: 2, minQuantity: 1, availableQuantity: 5, deadline: '2099-01-01T00:00:00Z' }), { ok: true });
});
test('selects highest eligible tier independent of input ordering', () => {
  const tiers = [{ min_quantity: 50, unit_price_paise: 44000 }, { min_quantity: 10, unit_price_paise: 47000 }, { min_quantity: 1, unit_price_paise: 50000 }];
  assert.equal(priceForQuantity(12, tiers).unitPricePaise, 47000);
  assert.equal(priceForQuantity(55, tiers).unitPricePaise, 44000);
  assert.equal(priceForQuantity(0, tiers).unlocked, false);
});
test('does not report negative savings when group price is higher', () => {
  assert.deepEqual(calculateSavings(45000, 47000, 3), { perUnitPaise: 0, totalPaise: 0 });
  assert.deepEqual(calculateSavings(50000, 44000, 3), { perUnitPaise: 6000, totalPaise: 18000 });
});

test('checkout amount allocates delivery fee proportionally without exceeding quoted total', async () => {
  const { calculateCheckoutAmounts } = await import('../lib/group-buying.mjs');
  const a = calculateCheckoutAmounts({ quantity: 2, finalQuantity: 3, unitPricePaise: 44000, totalDeliveryFeePaise: 101 });
  const b = calculateCheckoutAmounts({ quantity: 1, finalQuantity: 3, unitPricePaise: 44000, totalDeliveryFeePaise: 101 });
  assert.equal(a.subtotalPaise, 88000);
  assert.equal(a.deliveryFeePaise, 67);
  assert.equal(b.deliveryFeePaise, 33);
  assert.ok(a.deliveryFeePaise + b.deliveryFeePaise <= 101);
});

test('checkout rejects quantities exceeding final group quantity', async () => {
  const { calculateCheckoutAmounts } = await import('../lib/group-buying.mjs');
  assert.throws(() => calculateCheckoutAmounts({ quantity: 4, finalQuantity: 3, unitPricePaise: 100, totalDeliveryFeePaise: 0 }), /finalQuantity/);
});

test('checkout requires the exact final supplier-confirmed price', async () => {
  const { validateAcceptedPrice } = await import('../lib/group-buying.mjs');
  assert.deepEqual(validateAcceptedPrice({ acceptedUnitPricePaise: 44000, finalUnitPricePaise: 44000, finalizationStatus: 'confirmed' }), { ok: true });
  assert.deepEqual(validateAcceptedPrice({ acceptedUnitPricePaise: 45000, finalUnitPricePaise: 44000, finalizationStatus: 'confirmed' }), { ok: false, reason: 'accepted_price_mismatch' });
  assert.deepEqual(validateAcceptedPrice({ acceptedUnitPricePaise: 44000, finalUnitPricePaise: 44000, finalizationStatus: 'pending' }), { ok: false, reason: 'final_supplier_price_not_available' });
});

test('checkout rejects unsafe money values', async () => {
  const { calculateCheckoutAmounts } = await import('../lib/group-buying.mjs');
  assert.throws(() => calculateCheckoutAmounts({ quantity: 2, finalQuantity: 2, unitPricePaise: Number.MAX_SAFE_INTEGER, totalDeliveryFeePaise: 0 }), /subtotal exceeds/);
  assert.throws(() => calculateCheckoutAmounts({ quantity: 1, finalQuantity: 1, unitPricePaise: 10, totalDeliveryFeePaise: -1 }), /totalDeliveryFeePaise/);
});
