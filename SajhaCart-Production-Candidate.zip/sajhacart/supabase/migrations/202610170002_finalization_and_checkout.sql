-- SajhaCart phase 2: supplier-confirmed campaign finalization and price-accepted checkout.
-- Run after 202610170001_initial_schema.sql. No payment is captured by these functions.

alter table public.group_order_items
  add column if not exists final_quantity integer check (final_quantity is null or final_quantity >= 0),
  add column if not exists final_unit_price_paise bigint check (final_unit_price_paise is null or final_unit_price_paise >= 0),
  add column if not exists finalization_status text not null default 'pending'
    check (finalization_status in ('pending','confirmed','cancelled')),
  add column if not exists finalized_at timestamptz;

alter table public.customer_orders
  add column if not exists checkout_idempotency_key uuid;
create unique index if not exists customer_orders_checkout_idempotency_idx
  on public.customer_orders(user_id, checkout_idempotency_key)
  where checkout_idempotency_key is not null;


-- Residents may read finalized campaign items for their own active society so they can review the exact price and check out.
create policy "members read finalized campaign prices" on public.group_order_items for select to authenticated using (
  is_published=true and finalization_status in ('confirmed','cancelled') and exists(
    select 1 from public.group_orders g join public.society_memberships sm on sm.society_id=g.society_id
    where g.id=group_order_id and sm.user_id=auth.uid() and sm.status='active'
  )
);

-- Called by a trusted scheduled job/admin server using the service-role credential only.
-- The browser must never receive the service-role key.
create or replace function public.finalize_group_order_item(p_group_order_item_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_item public.group_order_items%rowtype;
  v_order public.group_orders%rowtype;
  v_quote public.supplier_quotes%rowtype;
  v_supplier_status text;
  v_supplier_stock integer;
  v_total integer;
  v_tier jsonb;
  v_price bigint;
begin
  if coalesce(current_setting('request.jwt.claim.role', true),'') <> 'service_role' then
    raise exception 'trusted_finalization_job_required' using errcode='42501';
  end if;
  select * into v_item from public.group_order_items where id=p_group_order_item_id for update;
  if not found then raise exception 'group_order_item_not_found' using errcode='P0002'; end if;
  if v_item.finalization_status <> 'pending' then
    return jsonb_build_object('item_id',v_item.id,'status',v_item.finalization_status,
      'final_quantity',v_item.final_quantity,'final_unit_price_paise',v_item.final_unit_price_paise,'idempotent_replay',true);
  end if;
  select * into v_order from public.group_orders where id=v_item.group_order_id for update;
  if not found then raise exception 'group_order_not_found' using errcode='P0002'; end if;
  if v_order.status <> 'open' or v_order.deadline > now() or v_item.deadline > now() then
    raise exception 'campaign_deadline_not_reached' using errcode='55000';
  end if;
  select coalesce(sum(c.quantity),0)::integer into v_total
    from public.group_order_commitments c
    where c.group_order_item_id=v_item.id and c.status='active';
  if v_item.available_quantity is not null and v_total > v_item.available_quantity then
    raise exception 'committed_quantity_exceeds_stock' using errcode='23514';
  end if;
  if v_total < v_item.min_quantity or v_item.supplier_quote_id is null or v_item.supplier_confirmed is not true then
    update public.group_order_items set final_quantity=v_total,final_unit_price_paise=null,
      finalization_status='cancelled',finalized_at=now(),updated_at=now() where id=v_item.id;
    update public.group_order_commitments set status='cancelled',updated_at=now()
      where group_order_item_id=v_item.id and status='active';
    update public.group_orders g set status='closed',updated_at=now()
      where g.id=v_order.id and not exists(select 1 from public.group_order_items i where i.group_order_id=g.id and i.finalization_status='pending');
    return jsonb_build_object('item_id',v_item.id,'status','cancelled','reason',
      case when v_total < v_item.min_quantity then 'minimum_quantity_not_reached' else 'supplier_quote_not_confirmed' end,
      'final_quantity',v_total,'refund_required',true);
  end if;
  select * into v_quote from public.supplier_quotes q where q.id=v_item.supplier_quote_id for share;
  if not found or v_quote.status <> 'approved' or v_quote.valid_until <= now() then
    update public.group_order_items set final_quantity=v_total,final_unit_price_paise=null,
      finalization_status='cancelled',finalized_at=now(),updated_at=now() where id=v_item.id;
    update public.group_order_commitments set status='cancelled',updated_at=now()
      where group_order_item_id=v_item.id and status='active';
    update public.group_orders g set status='closed',updated_at=now()
      where g.id=v_order.id and not exists(select 1 from public.group_order_items i where i.group_order_id=g.id and i.finalization_status='pending');
    return jsonb_build_object('item_id',v_item.id,'status','cancelled','reason','supplier_quote_expired_or_unapproved',
      'final_quantity',v_total,'refund_required',true);
  end if;
  select s.verification_status,sp.available_quantity into v_supplier_status,v_supplier_stock
    from public.supplier_products sp join public.suppliers s on s.id=sp.supplier_id
    join public.product_variants pv on pv.id=sp.variant_id
    where sp.id=v_quote.supplier_product_id and pv.id=v_item.variant_id for update of sp;
  if v_supplier_status is distinct from 'verified' then
    update public.group_order_items set final_quantity=v_total,final_unit_price_paise=null,
      finalization_status='cancelled',finalized_at=now(),updated_at=now() where id=v_item.id;
    update public.group_order_commitments set status='cancelled',updated_at=now()
      where group_order_item_id=v_item.id and status='active';
    update public.group_orders g set status='closed',updated_at=now()
      where g.id=v_order.id and not exists(select 1 from public.group_order_items i where i.group_order_id=g.id and i.finalization_status='pending');
    return jsonb_build_object('item_id',v_item.id,'status','cancelled','reason','supplier_not_verified',
      'final_quantity',v_total,'refund_required',true);
  end if;
  if v_supplier_stock is null or v_total > v_supplier_stock or v_total < v_quote.min_order_quantity then
    update public.group_order_items set final_quantity=v_total,final_unit_price_paise=null,
      finalization_status='cancelled',finalized_at=now(),updated_at=now() where id=v_item.id;
    update public.group_order_commitments set status='cancelled',updated_at=now()
      where group_order_item_id=v_item.id and status='active';
    update public.group_orders g set status='closed',updated_at=now()
      where g.id=v_order.id and not exists(select 1 from public.group_order_items i where i.group_order_id=g.id and i.finalization_status='pending');
    return jsonb_build_object('item_id',v_item.id,'status','cancelled','reason',
      case when v_total < v_quote.min_order_quantity then 'supplier_minimum_quantity_not_reached' else 'supplier_stock_insufficient' end,
      'final_quantity',v_total,'refund_required',true);
  end if;
  -- The approved supplier quote is canonical; copy its exact tier snapshot into the campaign.
  select x.tier into v_tier from jsonb_array_elements(v_quote.price_tiers) x(tier)
    where (x.tier->>'min_quantity') ~ '^[0-9]+$'
      and (x.tier->>'unit_price_paise') ~ '^[0-9]+$'
      and (x.tier->>'min_quantity')::integer <= v_total
    order by (x.tier->>'min_quantity')::integer desc limit 1;
  if v_tier is null then
    update public.group_order_items set final_quantity=v_total,final_unit_price_paise=null,
      finalization_status='cancelled',finalized_at=now(),updated_at=now() where id=v_item.id;
    update public.group_order_commitments set status='cancelled',updated_at=now()
      where group_order_item_id=v_item.id and status='active';
    update public.group_orders g set status='closed',updated_at=now()
      where g.id=v_order.id and not exists(select 1 from public.group_order_items i where i.group_order_id=g.id and i.finalization_status='pending');
    return jsonb_build_object('item_id',v_item.id,'status','cancelled','reason','no_supplier_price_tier_for_final_quantity',
      'final_quantity',v_total,'refund_required',true);
  end if;
  v_price := (v_tier->>'unit_price_paise')::bigint;
  -- Reserve inventory atomically so separate campaigns cannot both consume the same stock.
  update public.supplier_products set available_quantity=available_quantity-v_total
    where id=v_quote.supplier_product_id and available_quantity >= v_total;
  if not found then raise exception 'supplier_stock_reservation_failed' using errcode='23514'; end if;
  update public.group_order_items set tier_prices=v_quote.price_tiers,final_quantity=v_total,final_unit_price_paise=v_price,
    finalization_status='confirmed',finalized_at=now(),updated_at=now() where id=v_item.id;
  update public.group_order_commitments set committed_unit_price_paise=v_price,updated_at=now()
    where group_order_item_id=v_item.id and status='active';
  update public.group_orders g set status='closed',updated_at=now()
    where g.id=v_order.id and not exists(select 1 from public.group_order_items i where i.group_order_id=g.id and i.finalization_status='pending');
  insert into public.audit_events(actor_user_id,entity_type,entity_id,action,details)
    values(null,'group_order_item',v_item.id::text,'campaign_finalized',jsonb_build_object('quantity',v_total,'unit_price_paise',v_price));
  return jsonb_build_object('item_id',v_item.id,'status','confirmed','final_quantity',v_total,
    'final_unit_price_paise',v_price,'supplier_quote_id',v_quote.id,'refund_required',false);
end;
$$;
revoke all on function public.finalize_group_order_item(uuid) from public, anon, authenticated;
grant execute on function public.finalize_group_order_item(uuid) to service_role;

-- Converts a resident's active commitment into an order only after final supplier pricing is fixed.
-- The user must explicitly submit the exact final unit price shown by the server.
-- This function creates a pending-payment order only; it does not claim to collect payment.
create or replace function public.checkout_group_commitment(
  p_group_order_item_id uuid,
  p_accepted_unit_price_paise bigint,
  p_idempotency_key uuid
) returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid := auth.uid();
  v_item public.group_order_items%rowtype;
  v_commitment public.group_order_commitments%rowtype;
  v_order_id uuid;
  v_existing_status text;
  v_delivery_fee bigint := 0;
  v_subtotal bigint;
  v_total bigint;
  v_qty integer;
  v_final_qty integer;
begin
  if v_user is null then raise exception 'authentication_required' using errcode='28000'; end if;
  if p_idempotency_key is null then raise exception 'idempotency_key_required' using errcode='22023'; end if;
  if p_accepted_unit_price_paise is null or p_accepted_unit_price_paise < 0 then
    raise exception 'invalid_accepted_price' using errcode='22023';
  end if;
  select o.id,o.status::text into v_order_id,v_existing_status from public.customer_orders o
    where o.user_id=v_user and o.checkout_idempotency_key=p_idempotency_key;
  if found then
    if not exists(select 1 from public.customer_order_items oi where oi.order_id=v_order_id and oi.group_order_item_id=p_group_order_item_id) then
      raise exception 'idempotency_key_reused_for_different_item' using errcode='22023';
    end if;
    return jsonb_build_object('order_id',v_order_id,'status',v_existing_status,'idempotent_replay',true);
  end if;
  select * into v_item from public.group_order_items where id=p_group_order_item_id for update;
  if not found then raise exception 'group_order_item_not_found' using errcode='P0002'; end if;
  if v_item.finalization_status <> 'confirmed' or v_item.final_unit_price_paise is null then
    raise exception 'final_supplier_price_not_available' using errcode='55000';
  end if;
  if p_accepted_unit_price_paise <> v_item.final_unit_price_paise then
    raise exception 'accepted_price_mismatch_review_price_again' using errcode='22023';
  end if;
  select * into v_commitment from public.group_order_commitments c
    where c.group_order_item_id=v_item.id and c.user_id=v_user for update;
  if not found or v_commitment.status not in ('active','converted') then
    raise exception 'active_commitment_required' using errcode='55000';
  end if;
  if v_commitment.status='converted' then
    select o.id into v_order_id from public.customer_orders o
      join public.customer_order_items oi on oi.order_id=o.id
      where o.user_id=v_user and oi.group_order_item_id=v_item.id and o.status <> 'cancelled'
      order by o.created_at desc limit 1;
    if v_order_id is not null then
      select o.status::text into v_existing_status from public.customer_orders o where o.id=v_order_id;
      return jsonb_build_object('order_id',v_order_id,'status',v_existing_status,'idempotent_replay',true);
    end if;
    raise exception 'commitment_already_converted' using errcode='55000';
  end if;
  v_qty := v_commitment.quantity;
  v_final_qty := v_item.final_quantity;
  if v_final_qty is null or v_final_qty < v_qty or v_final_qty < 1 then
    raise exception 'invalid_final_quantity' using errcode='23514';
  end if;
  -- Allocate the supplier's quoted delivery fee proportionally by committed units, in paise.
  select q.delivery_fee_paise into v_delivery_fee from public.supplier_quotes q where q.id=v_item.supplier_quote_id;
  v_delivery_fee := coalesce(v_delivery_fee,0);
  -- Round down to paise so customer allocations never exceed the supplier's quoted total;
  -- any fractional-paise remainder is absorbed by the platform.
  v_delivery_fee := (v_delivery_fee * v_qty) / v_final_qty;
  v_subtotal := v_qty::bigint * v_item.final_unit_price_paise;
  v_total := v_subtotal + v_delivery_fee;
  insert into public.customer_orders(user_id,society_id,group_order_id,status,currency,subtotal_paise,delivery_fee_paise,tax_paise,total_paise,payment_due_at,address_snapshot,checkout_idempotency_key)
    select v_user,g.society_id,g.id,'pending_payment','INR',v_subtotal,v_delivery_fee,0,v_total,now()+interval '30 minutes','{}'::jsonb,p_idempotency_key
    from public.group_orders g where g.id=v_item.group_order_id returning id into v_order_id;
  insert into public.customer_order_items(order_id,variant_id,group_order_item_id,title_snapshot,unit_snapshot,quantity,unit_price_paise)
    values(v_order_id,v_item.variant_id,v_item.id,v_item.title,v_item.unit,v_qty,v_item.final_unit_price_paise);
  update public.group_order_commitments set status='converted',committed_unit_price_paise=v_item.final_unit_price_paise,updated_at=now()
    where id=v_commitment.id;
  insert into public.audit_events(actor_user_id,entity_type,entity_id,action,details)
    values(v_user,'customer_order',v_order_id::text,'checkout_order_created',jsonb_build_object('quantity',v_qty,'subtotal_paise',v_subtotal,'delivery_fee_paise',v_delivery_fee,'total_paise',v_total));
  return jsonb_build_object('order_id',v_order_id,'status','pending_payment','quantity',v_qty,
    'unit_price_paise',v_item.final_unit_price_paise,'subtotal_paise',v_subtotal,
    'delivery_fee_paise',v_delivery_fee,'total_paise',v_total,'payment_required',true,'idempotent_replay',false);
end;
$$;
revoke all on function public.checkout_group_commitment(uuid,bigint,uuid) from public, anon;
grant execute on function public.checkout_group_commitment(uuid,bigint,uuid) to authenticated;
