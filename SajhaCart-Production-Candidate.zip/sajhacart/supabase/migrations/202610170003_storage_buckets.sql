-- SajhaCart storage setup for Supabase Storage.
-- Product images are public-read but admin-write only. Supplier documents are private.
-- Run only after migration 202610170001_initial_schema.sql has been applied.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('product-images', 'product-images', true, 5242880, array['image/jpeg','image/png','image/webp']),
  ('supplier-documents', 'supplier-documents', false, 10485760, array['application/pdf','image/jpeg','image/png'])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- Public catalogue imagery can be read without signing in.
drop policy if exists "Public can view product images" on storage.objects;
create policy "Public can view product images"
on storage.objects for select
using (bucket_id = 'product-images');

-- Only an authenticated platform admin can add/replace/delete catalogue imagery.
drop policy if exists "Platform admins upload product images" on storage.objects;
create policy "Platform admins upload product images"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'product-images'
  and exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'platform_admin'
  )
);

drop policy if exists "Platform admins update product images" on storage.objects;
create policy "Platform admins update product images"
on storage.objects for update to authenticated
using (
  bucket_id = 'product-images'
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'platform_admin')
)
with check (
  bucket_id = 'product-images'
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'platform_admin')
);

drop policy if exists "Platform admins delete product images" on storage.objects;
create policy "Platform admins delete product images"
on storage.objects for delete to authenticated
using (
  bucket_id = 'product-images'
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'platform_admin')
);

-- Private supplier documents are stored under {supplier_uuid}/{filename}.
-- Supplier owners and platform admins may read/write only their authorized folder.
drop policy if exists "Supplier owners and admins read supplier documents" on storage.objects;
create policy "Supplier owners and admins read supplier documents"
on storage.objects for select to authenticated
using (
  bucket_id = 'supplier-documents'
  and (
    exists (
      select 1 from public.suppliers s
      where s.id::text = split_part(name, '/', 1) and s.owner_user_id = auth.uid()
    )
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'platform_admin')
  )
);

drop policy if exists "Supplier owners upload supplier documents" on storage.objects;
create policy "Supplier owners upload supplier documents"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'supplier-documents'
  and (
    exists (
      select 1 from public.suppliers s
      where s.id::text = split_part(name, '/', 1) and s.owner_user_id = auth.uid()
    )
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'platform_admin')
  )
);

drop policy if exists "Supplier owners update supplier documents" on storage.objects;
create policy "Supplier owners update supplier documents"
on storage.objects for update to authenticated
using (
  bucket_id = 'supplier-documents'
  and (
    exists (select 1 from public.suppliers s where s.id::text = split_part(name, '/', 1) and s.owner_user_id = auth.uid())
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'platform_admin')
  )
)
with check (
  bucket_id = 'supplier-documents'
  and (
    exists (select 1 from public.suppliers s where s.id::text = split_part(name, '/', 1) and s.owner_user_id = auth.uid())
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'platform_admin')
  )
);

drop policy if exists "Supplier owners delete supplier documents" on storage.objects;
create policy "Supplier owners delete supplier documents"
on storage.objects for delete to authenticated
using (
  bucket_id = 'supplier-documents'
  and (
    exists (select 1 from public.suppliers s where s.id::text = split_part(name, '/', 1) and s.owner_user_id = auth.uid())
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'platform_admin')
  )
);
