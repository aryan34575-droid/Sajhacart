BEGIN;

-- SajhaCart initial schema. Run in Supabase SQL Editor or with Supabase CLI.
-- Monetary values are integer paise. Never accept a client-submitted price as authoritative.
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

create type public.app_role as enum ('customer','society_admin','supplier','platform_admin');
create type public.membership_status as enum ('pending','active','rejected','left');
create type public.group_order_status as enum ('draft','open','closing','closed','cancelled','fulfilled');
create type public.customer_order_status as enum ('pending_payment','confirmed','packed','out_for_delivery','delivered','cancelled','refund_pending','refunded');
create type public.payment_status as enum ('created','pending','succeeded','failed','cancelled','refund_pending','partially_refunded','refunded');
create type public.delivery_status as enum ('scheduled','assigned','in_transit','delivered','failed','rescheduled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  preferred_language text not null default 'en' check (preferred_language in ('en','hi')),
  role public.app_role not null default 'customer',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name','')) on conflict (id) do nothing;
  return new;
end;
$$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create table public.cities (
  id uuid primary key default gen_random_uuid(), name text not null, state text not null,
  country_code char(2) not null default 'IN', is_active boolean not null default false,
  created_at timestamptz not null default now(), unique(name,state,country_code)
);
create table public.serviceable_pincodes (
  id uuid primary key default gen_random_uuid(), city_id uuid not null references public.cities(id),
  pincode char(6) not null check (pincode ~ '^[0-9]{6}$'), is_active boolean not null default false,
  unique(city_id,pincode)
);
create table public.societies (
  id uuid primary key default gen_random_uuid(), city_id uuid not null references public.cities(id),
  pincode_id uuid not null references public.serviceable_pincodes(id), name text not null,
  address_line text, invite_code_hash text unique, is_active boolean not null default false,
  created_by uuid references public.profiles(id), created_at timestamptz not null default now(),
  check (length(trim(name)) > 1)
);
create table public.society_memberships (
  id uuid primary key default gen_random_uuid(), society_id uuid not null references public.societies(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  status public.membership_status not null default 'pending', is_society_admin boolean not null default false,
  joined_at timestamptz not null default now(), unique(society_id,user_id)
);
create table public.suppliers (
  id uuid primary key default gen_random_uuid(), owner_user_id uuid references public.profiles(id),
  business_name text not null, gstin text, fssai_license text, contact_phone text,
  verification_status text not null default 'pending' check (verification_status in ('pending','verified','rejected','suspended')),
  created_at timestamptz not null default now()
);
create table public.products (
  id uuid primary key default gen_random_uuid(), name text not null, name_hi text,
  description text, description_hi text, category text not null,
  brand text, image_url text, is_active boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.product_variants (
  id uuid primary key default gen_random_uuid(), product_id uuid not null references public.products(id) on delete cascade,
  sku text unique, pack_quantity numeric(12,3) not null check (pack_quantity > 0), unit text not null,
  barcode text, mrp_paise bigint check (mrp_paise is null or mrp_paise >= 0), is_active boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.supplier_products (
  id uuid primary key default gen_random_uuid(), supplier_id uuid not null references public.suppliers(id),
  variant_id uuid not null references public.product_variants(id), supplier_sku text,
  available_quantity integer not null default 0 check (available_quantity >= 0),
  is_active boolean not null default false, created_at timestamptz not null default now(), unique(supplier_id,variant_id)
);
create table public.supplier_quotes (
  id uuid primary key default gen_random_uuid(), supplier_product_id uuid not null references public.supplier_products(id),
  min_order_quantity integer not null default 1 check (min_order_quantity > 0),
  -- JSON array: [{"min_quantity":1,"unit_price_paise":50000}]. Snapshot the approved quote into a campaign.
  price_tiers jsonb not null check (jsonb_typeof(price_tiers) = 'array' and jsonb_array_length(price_tiers) > 0),
  delivery_fee_paise bigint not null default 0 check (delivery_fee_paise >= 0), valid_until timestamptz not null,
  status text not null default 'submitted' check (status in ('submitted','approved','rejected','expired')),
  reviewed_by uuid references public.profiles(id), reviewed_at timestamptz, created_at timestamptz not null default now()
);
create table public.group_orders (
  id uuid primary key default gen_random_uuid(), society_id uuid not null references public.societies(id),
  title text not null, description text, status public.group_order_status not null default 'draft',
  opens_at timestamptz not null default now(), deadline timestamptz not null,
  delivery_window_start timestamptz, delivery_window_end timestamptz,
  cancellation_policy text not null default 'If minimum quantity is not reached, the order is cancelled and eligible payments are refunded.',
  created_by uuid references public.profiles(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  check (deadline > opens_at), check (delivery_window_end is null or delivery_window_start is null or delivery_window_end >= delivery_window_start)
);
create table public.group_order_items (
  id uuid primary key default gen_random_uuid(), group_order_id uuid not null references public.group_orders(id) on delete cascade,
  supplier_quote_id uuid references public.supplier_quotes(id), variant_id uuid not null references public.product_variants(id),
  title text not null, description text, category text not null, unit text not null, product_emoji text,
  committed_quantity integer not null default 0 check (committed_quantity >= 0), target_quantity integer not null check (target_quantity > 0),
  min_quantity integer not null default 1 check (min_quantity > 0), available_quantity integer check (available_quantity is null or available_quantity >= 0),
  tier_prices jsonb not null check (jsonb_typeof(tier_prices) = 'array' and jsonb_array_length(tier_prices) > 0),
  current_unit_price_paise bigint check (current_unit_price_paise is null or current_unit_price_paise >= 0),
  supplier_confirmed boolean not null default false, is_published boolean not null default false,
  deadline timestamptz not null, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index group_order_items_published_deadline_idx on public.group_order_items(is_published, deadline);
create index group_orders_society_status_idx on public.group_orders(society_id,status,deadline);

create table public.group_order_commitments (
  id uuid primary key default gen_random_uuid(), group_order_item_id uuid not null references public.group_order_items(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  quantity integer not null check (quantity > 0), status text not null default 'active' check (status in ('active','withdrawn','converted','cancelled')),
  idempotency_key uuid not null, committed_unit_price_paise bigint check (committed_unit_price_paise is null or committed_unit_price_paise >= 0),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(group_order_item_id,user_id), unique(user_id,idempotency_key)
);
create index commitments_item_status_idx on public.group_order_commitments(group_order_item_id,status);

create table public.customer_orders (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id),
  society_id uuid not null references public.societies(id), group_order_id uuid references public.group_orders(id),
  status public.customer_order_status not null default 'pending_payment', currency char(3) not null default 'INR',
  subtotal_paise bigint not null default 0 check (subtotal_paise >= 0), delivery_fee_paise bigint not null default 0 check (delivery_fee_paise >= 0),
  tax_paise bigint not null default 0 check (tax_paise >= 0), total_paise bigint not null default 0 check (total_paise >= 0),
  payment_due_at timestamptz, address_snapshot jsonb not null default '{}'::jsonb, customer_note text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.customer_order_items (
  id uuid primary key default gen_random_uuid(), order_id uuid not null references public.customer_orders(id) on delete cascade,
  variant_id uuid not null references public.product_variants(id), group_order_item_id uuid references public.group_order_items(id),
  title_snapshot text not null, unit_snapshot text not null, quantity integer not null check (quantity > 0),
  unit_price_paise bigint not null check (unit_price_paise >= 0), line_total_paise bigint generated always as (quantity::bigint * unit_price_paise) stored
);
create table public.payments (
  id uuid primary key default gen_random_uuid(), order_id uuid not null references public.customer_orders(id), user_id uuid not null references public.profiles(id),
  provider text not null default 'manual_test', provider_payment_id text, idempotency_key uuid not null,
  amount_paise bigint not null check (amount_paise >= 0), status public.payment_status not null default 'created',
  payment_method text check (payment_method is null or payment_method in ('upi','card','netbanking','cod','test')),
  provider_payload jsonb not null default '{}'::jsonb, verified_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(provider,provider_payment_id), unique(user_id,idempotency_key)
);
create table public.refunds (
  id uuid primary key default gen_random_uuid(), payment_id uuid not null references public.payments(id),
  provider_refund_id text, amount_paise bigint not null check (amount_paise > 0),
  reason text not null, status text not null default 'requested' check (status in ('requested','processing','succeeded','failed','cancelled')),
  idempotency_key uuid not null unique, provider_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.deliveries (
  id uuid primary key default gen_random_uuid(), order_id uuid not null references public.customer_orders(id),
  society_id uuid not null references public.societies(id), status public.delivery_status not null default 'scheduled',
  scheduled_start timestamptz, scheduled_end timestamptz, delivered_at timestamptz, proof_url text, delivery_note text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.audit_events (
  id bigint generated always as identity primary key, actor_user_id uuid references public.profiles(id),
  entity_type text not null, entity_id text not null, action text not null,
  details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
create index customer_orders_user_created_idx on public.customer_orders(user_id,created_at desc);
create index payments_order_status_idx on public.payments(order_id,status);

-- Atomic commitment RPC: lock the campaign item, verify membership and deadline, then update quantity.
-- The caller cannot pass a price; price is selected from the server-owned quote snapshot.
create or replace function public.commit_to_group_order(p_group_order_item_id uuid, p_quantity integer, p_idempotency_key uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid := auth.uid(); v_item public.group_order_items%rowtype; v_order public.group_orders%rowtype;
  v_existing public.group_order_commitments%rowtype; v_total integer; v_tier jsonb; v_price bigint; v_threshold integer;
  v_member boolean; v_new_qty integer;
begin
  if v_user is null then raise exception 'authentication_required' using errcode='28000'; end if;
  if p_quantity is null or p_quantity < 1 or p_quantity > 100 then raise exception 'invalid_quantity' using errcode='22023'; end if;
  if p_idempotency_key is null then raise exception 'idempotency_key_required' using errcode='22023'; end if;
  select * into v_item from public.group_order_items where id=p_group_order_item_id for update;
  if not found then raise exception 'group_order_item_not_found' using errcode='P0002'; end if;
  select * into v_order from public.group_orders where id=v_item.group_order_id;
  if not found or v_order.status <> 'open' or v_item.is_published is not true then raise exception 'order_not_open' using errcode='55000'; end if;
  if v_order.deadline <= now() or v_item.deadline <= now() then raise exception 'deadline_passed' using errcode='55000'; end if;
  select exists(select 1 from public.society_memberships sm where sm.society_id=v_order.society_id and sm.user_id=v_user and sm.status='active') into v_member;
  if not v_member then raise exception 'active_society_membership_required' using errcode='42501'; end if;
  if v_item.available_quantity is not null and p_quantity > v_item.available_quantity then raise exception 'insufficient_stock' using errcode='22023'; end if;
  select * into v_existing from public.group_order_commitments where group_order_item_id=p_group_order_item_id and user_id=v_user for update;
  if found then
    -- A retry with the same idempotency key is safe and does not mutate the commitment.
    if v_existing.idempotency_key=p_idempotency_key then
      return jsonb_build_object('commitment_id',v_existing.id,'quantity',v_existing.quantity,'idempotent_replay',true,'status',v_existing.status);
    end if;
    if v_existing.status <> 'active' then raise exception 'existing_commitment_not_active' using errcode='55000'; end if;
    v_new_qty := p_quantity;
    update public.group_order_commitments set quantity=v_new_qty,idempotency_key=p_idempotency_key,updated_at=now() where id=v_existing.id;
  else
    v_new_qty := p_quantity;
    insert into public.group_order_commitments(group_order_item_id,user_id,quantity,idempotency_key,status)
      values(p_group_order_item_id,v_user,v_new_qty,p_idempotency_key,'active');
  end if;
  select coalesce(sum(quantity),0)::integer into v_total from public.group_order_commitments where group_order_item_id=p_group_order_item_id and status='active';
  if v_item.available_quantity is not null and v_total > v_item.available_quantity then raise exception 'insufficient_stock_for_group' using errcode='22023'; end if;
  update public.group_order_items set committed_quantity=v_total,updated_at=now() where id=p_group_order_item_id;
  select t into v_tier from jsonb_array_elements(v_item.tier_prices) as x(t)
    where (t->>'min_quantity') ~ '^[0-9]+$' and (t->>'unit_price_paise') ~ '^[0-9]+$' and (t->>'min_quantity')::integer <= v_total
    order by (t->>'min_quantity')::integer desc limit 1;
  if v_tier is not null then
    v_price := (v_tier->>'unit_price_paise')::bigint; v_threshold := (v_tier->>'min_quantity')::integer;
  else
    select t into v_tier from jsonb_array_elements(v_item.tier_prices) as x(t)
      where (t->>'min_quantity') ~ '^[0-9]+$' and (t->>'unit_price_paise') ~ '^[0-9]+$'
      order by (t->>'min_quantity')::integer asc limit 1;
    v_price := null; v_threshold := case when v_tier is null then v_item.target_quantity else (v_tier->>'min_quantity')::integer end;
  end if;
  update public.group_order_commitments set committed_unit_price_paise=v_price where group_order_item_id=p_group_order_item_id and user_id=v_user and status='active';
  insert into public.audit_events(actor_user_id,entity_type,entity_id,action,details)
    values(v_user,'group_order_item',p_group_order_item_id::text,'commitment_upserted',jsonb_build_object('quantity',v_new_qty,'committed_total',v_total));
  return jsonb_build_object('commitment_quantity',v_new_qty,'committed_quantity',v_total,'target_quantity',v_item.target_quantity,
    'price_tier_unlocked',v_price is not null,'unit_price_paise',v_price,'next_or_selected_threshold',v_threshold,'idempotent_replay',false);
end;
$$;
revoke all on function public.commit_to_group_order(uuid,integer,uuid) from public;
grant execute on function public.commit_to_group_order(uuid,integer,uuid) to authenticated;

-- Updated-at helper.
create function public.set_updated_at() returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at=now(); return new; end; $$;
create trigger profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger group_orders_updated_at before update on public.group_orders for each row execute function public.set_updated_at();
create trigger group_order_items_updated_at before update on public.group_order_items for each row execute function public.set_updated_at();
create trigger commitments_updated_at before update on public.group_order_commitments for each row execute function public.set_updated_at();
create trigger customer_orders_updated_at before update on public.customer_orders for each row execute function public.set_updated_at();
create trigger payments_updated_at before update on public.payments for each row execute function public.set_updated_at();
create trigger refunds_updated_at before update on public.refunds for each row execute function public.set_updated_at();
create trigger deliveries_updated_at before update on public.deliveries for each row execute function public.set_updated_at();

-- RLS: default deny unless a policy explicitly grants access.
alter table public.profiles enable row level security;
alter table public.cities enable row level security;
alter table public.serviceable_pincodes enable row level security;
alter table public.societies enable row level security;
alter table public.society_memberships enable row level security;
alter table public.suppliers enable row level security;
alter table public.products enable row level security;
alter table public.product_variants enable row level security;
alter table public.supplier_products enable row level security;
alter table public.supplier_quotes enable row level security;
alter table public.group_orders enable row level security;
alter table public.group_order_items enable row level security;
alter table public.group_order_commitments enable row level security;
alter table public.customer_orders enable row level security;
alter table public.customer_order_items enable row level security;
alter table public.payments enable row level security;
alter table public.refunds enable row level security;
alter table public.deliveries enable row level security;
alter table public.audit_events enable row level security;

create policy "profiles read self" on public.profiles for select to authenticated using (id=auth.uid());
create policy "profiles update self" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());
create policy "active cities public read" on public.cities for select to anon,authenticated using (is_active=true);
create policy "active pincodes public read" on public.serviceable_pincodes for select to anon,authenticated using (is_active=true);
create policy "active societies public read" on public.societies for select to authenticated using (is_active=true);
create policy "members read their memberships" on public.society_memberships for select to authenticated using (user_id=auth.uid());
create policy "members read own commitments" on public.group_order_commitments for select to authenticated using (user_id=auth.uid());
create policy "customers read own orders" on public.customer_orders for select to authenticated using (user_id=auth.uid());
create policy "customers read own order items" on public.customer_order_items for select to authenticated using (exists(select 1 from public.customer_orders o where o.id=order_id and o.user_id=auth.uid()));
create policy "customers read own payments" on public.payments for select to authenticated using (user_id=auth.uid());
create policy "customers read own refunds" on public.refunds for select to authenticated using (exists(select 1 from public.payments p where p.id=payment_id and p.user_id=auth.uid()));
create policy "customers read own deliveries" on public.deliveries for select to authenticated using (exists(select 1 from public.customer_orders o where o.id=order_id and o.user_id=auth.uid()));
-- Only published items in open campaigns are visible to signed-in customers.
create policy "customers read published open campaigns" on public.group_order_items for select to authenticated using (
  is_published=true and exists(select 1 from public.group_orders g join public.society_memberships sm on sm.society_id=g.society_id
    where g.id=group_order_id and g.status='open' and sm.user_id=auth.uid() and sm.status='active')
);
create policy "customers read published products" on public.products for select to authenticated using (is_active=true);
create policy "customers read active variants" on public.product_variants for select to authenticated using (is_active=true and exists(select 1 from public.products p where p.id=product_id and p.is_active=true));
-- Supplier/admin writes are intentionally not opened to clients in this initial migration.
-- Add narrowly scoped policies only after the admin approval workflow is implemented and tested.

-- Join using an invite code distributed by the society administrator.
-- Store invite_code_hash as encode(digest(lower(trim(code)), 'sha256'), 'hex') from a trusted admin tool.
create or replace function public.join_society_with_invite_code(p_code text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_user uuid := auth.uid(); v_society public.societies%rowtype; v_membership public.society_memberships%rowtype;
begin
  if v_user is null then raise exception 'authentication_required' using errcode='28000'; end if;
  if p_code is null or length(trim(p_code)) < 6 or length(trim(p_code)) > 80 then raise exception 'invalid_invite_code' using errcode='22023'; end if;
  select s.* into v_society from public.societies s
    join public.cities c on c.id=s.city_id and c.is_active=true
    join public.serviceable_pincodes p on p.id=s.pincode_id and p.is_active=true
    where s.is_active=true and s.invite_code_hash=encode(extensions.digest(lower(trim(p_code)), 'sha256'),'hex') limit 1;
  if not found then raise exception 'invalid_or_inactive_invite_code' using errcode='P0002'; end if;
  insert into public.society_memberships(society_id,user_id,status) values(v_society.id,v_user,'active')
    on conflict(society_id,user_id) do update set status='active' returning * into v_membership;
  insert into public.audit_events(actor_user_id,entity_type,entity_id,action,details)
    values(v_user,'society',v_society.id::text,'member_joined_with_invite',jsonb_build_object('membership_id',v_membership.id));
  return jsonb_build_object('society_id',v_society.id,'society_name',v_society.name,'membership_status',v_membership.status);
end;
$$;
revoke all on function public.join_society_with_invite_code(text) from public;
grant execute on function public.join_society_with_invite_code(text) to authenticated;

-- Users must not be able to grant themselves elevated application roles via profile updates.
create or replace function public.prevent_self_role_escalation() returns trigger language plpgsql set search_path = '' as $$
begin
  if new.role is distinct from old.role and coalesce(current_setting('request.jwt.claim.role', true),'') <> 'service_role' then
    raise exception 'profile_role_changes_require_trusted_admin' using errcode='42501';
  end if;
  return new;
end;
$$;
create trigger profiles_prevent_role_escalation before update on public.profiles for each row execute function public.prevent_self_role_escalation();

COMMIT;
