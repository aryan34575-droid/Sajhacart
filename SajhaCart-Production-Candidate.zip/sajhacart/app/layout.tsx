import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'SajhaCart — Buy together. Save together.',
  description: 'Join your apartment society to unlock transparent bulk prices on household essentials.',
  applicationName: 'SajhaCart',
  manifest: '/manifest.webmanifest',
  appleWebApp: { capable: true, statusBarStyle: 'default', title: 'SajhaCart' },
};
export const viewport: Viewport = { themeColor: '#163c2e', width: 'device-width', initialScale: 1 };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
